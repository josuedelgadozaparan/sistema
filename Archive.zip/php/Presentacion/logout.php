<?php
session_start();
session_unset();
session_destroy();
//$parametros_cookies = session_get_cookie_params(); 
//setcookie(session_name(),0,1,$parametros_cookies["path"]);


/*
//iniciar sesion antes que todo
session_start();
session_destroy();
unset($_SESSION["aaa"]);
unset($_SESSION["bbb"]);
//libera la sesion
session_unset();
//dirigirse a la pagina que se desea ver
echo "<script>document.location.href='../../index.php';</script>";
*/


header("Location: ../../index.php");
?>