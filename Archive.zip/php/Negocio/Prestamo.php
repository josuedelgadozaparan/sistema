<?php

require_once dirname(__FILE__) . '/../Datos/ProcesoPrestamo.php';

class Prestamo {
    public $vacio=false;
    
    public function ValidarConsultarClientePrestamo($cedula) {
        if($cedula==""){
           
           $this->vacio=true;
            return $this->vacio;
        }else{
        $dato=new ProcesoPrestamo();
        $this->vacio= $dato->ConsultarPretamoCedula($cedula);
        }
           
       
    }

    public function ValidarConsultarClienteP_id($id) {
        
        $dato=new ProcesoPrestamo();
        $json_dato= $dato->ConsultarPretamo_id($id) ;
        return  $json_dato;
        
           
       
    }

    public function ValidarInsertarPrestamo($cod,$fecha,$valor,$estado,$porcentaje,$valortotal,$saldo,$cuotas,$tipo,$cxu,$descripcion,$idcliente){

    $dato=new ProcesoPrestamo();
    $dato->InsertarPrestamo($cod, $fecha, $valor, $estado, $porcentaje, $valortotal, $saldo, $cuotas, $tipo, $cxu, $descripcion, $idcliente);
    

 }
 public function ValidarActualizarPrestamosaldo($saldo,$id){
$dato=new ProcesoPrestamo();
$dato->ActualizarPrestamosaldo($saldo, $id);

 
  

 
 }


public function ValidarActualizarRegistroCuota($id){
$dato=new ProcesoPrestamo();
$dato->ActualizarRegistroCuota($id);

 
  

 
 }
 public function ValidarActualizarEstadoPrestamo($id,$est){

$dato=new ProcesoPrestamo();
$dato->ActualizarEstadoPrestamo($id,$est);
    
}







    /*

    public function ValidarConsultarClienteCedulaPrestamo($cedula) {
        if($cedula==""){
            echo 'favor ingrese el numero de cedula';
           $this->vacio=true;
            return $this->vacio;
        }else{
        $dato=new ProcesoCliente();
        $this->vacio= $dato->ConsultarClienteCedulaPrestamo($cedula);
        return $this->vacio;
        }
           
       
    }
    
    public function ValidarConsultarClienteId($idcli){
       $dato=new ProcesoCliente();
        $this->vacio= $dato->ConsultarClienteId($idcli);
        return $this->vacio; 
        
    }
    
    
    public function ValidarConsultarClienteTodos() {
        $dato=new ProcesoCliente();
        $this->vacio= $dato->ConsultarClienteTodos();
        return $this->vacio;
    }
    
    
     public function ValidarInsertarCliente($ced,$nom,$ape,$dirres,$dirofi,$telres,$telofi,$idusu){
        $dato=new ProcesoCliente();
        $dato->InsertarCliente($ced, $nom, $ape, $dirres, $dirofi, $telres, $telofi, $idusu);
        
    }
    
    
    public function ValidarActualizarCliente($ced,$nom,$ape,$dirres,$dirofi,$telres,$telofi,$idusu,$id){
        $dato=new ProcesoCliente();
        $dato->ActualizarCliente($ced, $nom, $ape, $dirres, $dirofi, $telres, $telofi, $idusu, $id);
        
    }

    */
    
}
