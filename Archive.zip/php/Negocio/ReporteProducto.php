<?php

require_once dirname(__FILE__) .'/../Datos/ProcesoReporteProducto.php';

class ReporteProducto {
   
  
       
       
       
  
    
    
}
