<?php

require_once dirname(__FILE__) .'/../Datos/ProcesoAbono.php';

class Abono {
    public $vacio=false;
    
    

    public function ValidarConsultarAbonos($id) {
        
        $dato=new ProcesoAbono();
        $dato->ConsultarAbonos($id) ;
         }

    public function ValidarInsertarAbono($idpre,$valor,$pendiente,$fecha){
        
        $dato=new ProcesoAbono();
        $dato->InsertarAbono($idpre, $valor, $pendiente, $fecha);
         
    }
   
}
